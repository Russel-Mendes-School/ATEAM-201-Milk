README

Course: cs400
Semester: Fall 2019
Project name: Milk Weights
Team Memebers:
1. Russel Mendes, Lec 002, rmendes@wisc.edu
2. Akshay Bolda, Lec 001, bolda@wisc.edu
3. Roland Jiang, Lec 002, rjian45@wisc.edu
4. Will Hu, Lec 002, whu72@wisc.edu
5. Ben Rinvelt, Lec 002, Rinvelt@wisc.edu

Russel Mendes, Will Hu, and Roland Jiang were on the same xteam